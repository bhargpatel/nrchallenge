/**
 *
 */
package com.example.newrelicchallenge;

import java.io.IOException;


import org.junit.Test;


public class NewRelicChallengeAppTests {

    @Test
    public void testTheSampleFile() throws IOException, InterruptedException {

    }

    //Tests for empty filr

    // Test for Big file

    //Test for multiple files

}
