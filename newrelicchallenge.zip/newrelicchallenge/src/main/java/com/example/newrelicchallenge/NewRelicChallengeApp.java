package com.example.newrelicchallenge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@SpringBootApplication
public class NewRelicChallengeApp {

    private static Integer numberOfThreeWordSequence = 100;

    public static void main(String[] args) {
        SpringApplication.run(NewRelicChallengeApp.class, args);

        System.out.println("File paths as arguments size : " + args.length);

        // Print all args
        for (String s: args) {
            System.out.println(s);
        }

        System.out.println("Give the file name as Input and/or press enter");

        ArrayList < String > combinedFilePathList = new ArrayList < > ();

        combinedFilePathList.addAll(Arrays.asList(args));

        //todo Fix scanner
        //for Stdin file
        // InputStreamReader isReader = new InputStreamReader(System.in);
        // BufferedReader br = new BufferedReader(isReader);
        // printMostOccuredSubsutringWithOccurences(br);

        // Scanner anc = new Scanner(System.in);
        //combinedFilePathList.add(anc.nextLine());

        // System.out.println("Give the file name as Input and press enter");
        // Scanner anc = new Scanner(System.in);

        // ArrayList<String> combinedFilePathList = new ArrayList<>();
        // combinedFilePathList.addAll(Arrays.asList(args));
        //combinedFilePathList.add(anc.nextLine());

        // method to find and print words
        findMostOccuredSubsutring(combinedFilePathList);

    }

    private static void findMostOccuredSubsutring(ArrayList < String > combinedFilePathList) {
        try {

            for (String currentFile: combinedFilePathList) {

                System.out.println("::::::::::::::::::::::::::::::::::::");
                System.out.println(":: RESULTS FOR :: " + currentFile);
                System.out.println("::::::::::::::::::::::::::::::::::::");

                FileInputStream fstream = new FileInputStream(currentFile);
                DataInputStream in = new DataInputStream(fstream);
                BufferedReader currentFileReader = new BufferedReader(new InputStreamReader( in ));

                // convert file to list of strings
                printMostOccuredSubsutringWithOccurences(currentFileReader);

            }

        } catch (Exception e) {

            System.err.println("Error: " + e.getMessage());

        }
    }

    /**
     */
    private static void printMostOccuredSubsutringWithOccurences(BufferedReader currentFileReader) throws IOException {

        //System.out.println("Finding Most Occurred Substring With Occurrences Start");

        // Read the file
        String fileasString = "";

        StringBuilder fileasSb = new StringBuilder();

        while ((fileasString = currentFileReader.readLine()) != null) {

            fileasSb.append(fileasString).append("\n");

        }

        String fileAsString = fileasSb.toString().trim();

        ArrayList < String > words = new ArrayList < String > ();


        // Formate the file


        fileAsString = fileAsString.replaceAll("\\p{Punct}", " ");
        fileAsString = fileAsString.replaceAll("\\n+", " ");
        Pattern pattern = Pattern.compile("((\\w+'\\w+)|(\\w+-?\\w+)|(\\w+)|(\\r+))");

        Matcher matchfound = pattern.matcher(fileAsString);

        while (matchfound.find()) {

            words.add(matchfound.group().toLowerCase());

        }

        //put all strings and integer frequencies into a hashmap
        HashMap < String, Integer > map = new HashMap < > ();

        long start = System.currentTimeMillis();

        for (int i = 0; i < (words.size() - 2); i++) {

            StringBuilder sb = new StringBuilder();

            String threeWordstring = sb.append(words.get(i)).append(" ").append(words.get(i + 1)).append(" ").append(words.get(i + 2)).toString();

            map.put(threeWordstring, map.getOrDefault(threeWordstring, 0) + 1);

        }

        long end = System.currentTimeMillis();
        long resultTime = end - start;

        System.out.println("Time to find results in ms: " + resultTime);

        //put all map entries into a maxHeap


        // Create a list from elements of HashMap
        List<Map.Entry<String, Integer> > list =
                new LinkedList<Map.Entry<String, Integer> >(map.entrySet());

        // Sort the list
        Collections.sort(list, Comparator.comparing(Map.Entry::getValue));

        PriorityQueue < Map.Entry < String, Integer >> maxHeap =
                new PriorityQueue < > ((a, b) -> a.getValue() == b.getValue() ?
                        a.getKey().compareTo(b.getKey()) :
                        b.getValue() - a.getValue());

        for (Map.Entry < String, Integer > entry: map.entrySet()) {
            maxHeap.offer(entry);
        }

        // PRINT the output

        for (int i = 0; i < numberOfThreeWordSequence && i < maxHeap.size(); i++) {

            System.out.println(i + 1 + ") " + maxHeap.peek().getKey() + " = " + maxHeap.poll().getValue().toString());

        }

        //System.out.println("Finding Most Occurred Substring With Occurrences Completed");

    }

}